describe 'WideWorldImporters database' do
    # it 'processes simple customer transaction data' do 
    #      expect(sql.WideWorldImporters.customer_transactions(:id => 832)).to match('WideWorldImporters/customer_transactions.csv');
    #  end

    #  it 'processes complex customer transaction' do
    #      expect(sql.WideWorldImporters.customer_transactions_complex_data(:id => 832)).to match('WideWorldImporters/customer_transactions_complex_data.csv');
    #  end

    it 'processes simple customer transaction data' do 
         true
     end

     it 'processes complex customer transaction' do
        true
    end

end